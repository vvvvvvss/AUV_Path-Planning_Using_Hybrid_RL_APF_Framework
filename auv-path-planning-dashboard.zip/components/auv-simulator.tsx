'use client'

import { Canvas, useFrame } from '@react-three/fiber'
import { OrbitControls, PerspectiveCamera, Line, Html } from '@react-three/drei'
import { useRef, useState } from 'react'
import * as THREE from 'three'

const paths = [
  { color: '#4dd9ff', points: [[-4, -1.4, 3], [-2.3, -1.1, 2.1], [-0.8, -0.6, 1.2], [0.6, -0.5, 0.3], [2.8, 0.1, -1.5], [4, 1.2, -2.7]] as [number, number, number][], label: 'A* Spline' },
  { color: '#f3b34c', points: [[-4, -1.4, 3], [-3.2, -2.1, 1.5], [-1.8, -2.2, -0.3], [0.2, -1.7, -1.3], [2.5, -0.7, -2.2], [4, 1.2, -2.7]] as [number, number, number][], label: 'RRT*' },
  { color: '#c77dff', points: [[-4, -1.4, 3], [-2.8, 0.1, 2.7], [-1.3, 1.3, 1.4], [0.5, 1.2, 0.3], [2.2, 0.4, -1.4], [4, 1.2, -2.7]] as [number, number, number][], label: 'Dijkstra' },
]

function Auv({ running }: { running: boolean }) {
  const ref = useRef<THREE.Group>(null)
  useFrame((_, delta) => {
    if (ref.current && running) ref.current.position.y = -1.4 + Math.sin(Date.now() * 0.0015) * 0.06
  })
  return <group ref={ref} position={[-4, -1.4, 3]} rotation={[0, -0.45, 0]}>
    <mesh castShadow><capsuleGeometry args={[0.32, 1.25, 8, 16]} /><meshStandardMaterial color="#d8e7eb" metalness={0.7} roughness={0.22} /></mesh>
    <mesh position={[0, 0, -0.78]} rotation={[Math.PI / 2, 0, 0]}><coneGeometry args={[0.25, 0.38, 16]} /><meshStandardMaterial color="#89b8c2" metalness={0.65} /></mesh>
    <mesh position={[0, 0, 0.79]} rotation={[-Math.PI / 2, 0, 0]}><coneGeometry args={[0.19, 0.28, 16]} /><meshStandardMaterial color="#f3b34c" /></mesh>
    <mesh position={[0, 0.32, 0.1]}><boxGeometry args={[0.1, 0.05, 0.55]} /><meshStandardMaterial color="#e74f68" emissive="#e74f68" emissiveIntensity={2} /></mesh>
    <Html distanceFactor={8} position={[0, 0.6, 0]}><div className="rounded border border-cyan-400/30 bg-slate-950/80 px-2 py-1 font-mono text-[9px] text-cyan-200">AUV-07</div></Html>
  </group>
}

function Obstacle({ position, scale, label }: { position: [number, number, number], scale: [number, number, number], label: string }) {
  return <group position={position}>
    <mesh castShadow><icosahedronGeometry args={[1, 1]} /><meshStandardMaterial color="#263c4b" emissive="#172933" emissiveIntensity={0.8} roughness={0.75} /></mesh>
    <mesh scale={scale}><icosahedronGeometry args={[1.03, 1]} /><meshBasicMaterial color="#e74f68" wireframe transparent opacity={0.45} /></mesh>
    <Html distanceFactor={9} position={[0, 1.15, 0]}><div className="font-mono text-[9px] text-rose-300/80">{label}</div></Html>
  </group>
}

function Scene({ running, showPaths }: { running: boolean, showPaths: boolean }) {
  return <>
    <color attach="background" args={['#07141f']} />
    <fog attach="fog" args={['#07141f', 8, 24]} />
    <ambientLight intensity={0.55} color="#6ca9bf" />
    <directionalLight position={[4, 7, 5]} intensity={2.2} color="#c9f4ff" />
    <pointLight position={[-4, 0, 2]} color="#26b8dc" intensity={10} distance={12} />
    <PerspectiveCamera makeDefault position={[8, 5.5, 10]} fov={42} />
    <OrbitControls enablePan={false} minDistance={6} maxDistance={18} target={[0, -0.5, 0]} />
    <gridHelper args={[18, 18, '#173746', '#0d2531']} rotation={[0, 0, 0]} position={[0, -3, 0]} />
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -3.04, 0]}><planeGeometry args={[22, 22]} /><meshStandardMaterial color="#071a27" transparent opacity={0.65} /></mesh>
    {showPaths && paths.map((path) => <Line key={path.label} points={path.points} color={path.color} lineWidth={2.2} transparent opacity={path.label === 'A* Spline' ? 1 : 0.52} />)}
    <mesh position={[4, 1.2, -2.7]}><sphereGeometry args={[0.18, 16, 16]} /><meshBasicMaterial color="#4dffb2" /></mesh>
    <Html distanceFactor={9} position={[4, 1.2, -2.7]}><div className="ml-3 -mt-1 whitespace-nowrap rounded border border-emerald-400/40 bg-slate-950/80 px-2 py-1 font-mono text-[9px] text-emerald-300">GOAL // 04:22:18</div></Html>
    <Auv running={running} />
    <Obstacle position={[-1.3, -0.7, 0.5]} scale={[1.2, 1, 1]} label="OBS-12 // 18m" />
    <Obstacle position={[1.7, 0.2, -0.9]} scale={[0.8, 1.4, 1]} label="OBS-07 // 24m" />
    <Obstacle position={[0.4, -1.8, 2]} scale={[1.1, 0.7, 1]} label="OBS-21 // 31m" />
  </>
}

export function AuvSimulator({ running, showPaths }: { running: boolean, showPaths: boolean }) {
  return <div className="relative h-full min-h-[400px] w-full overflow-hidden rounded-lg border border-cyan-300/15">
    <Canvas shadows dpr={[1, 1.5]}><Scene running={running} showPaths={showPaths} /></Canvas>
    <div className="pointer-events-none absolute left-4 top-4 font-mono text-[10px] uppercase tracking-[0.18em] text-cyan-200/65">Live 3D Occupancy Field</div>
    <div className="pointer-events-none absolute bottom-4 left-4 flex gap-4 rounded border border-white/10 bg-slate-950/70 px-3 py-2 font-mono text-[9px] text-slate-400 backdrop-blur"><span><i className="mr-1 inline-block size-1.5 rounded-full bg-cyan-300" />A* SPLINE</span><span><i className="mr-1 inline-block size-1.5 rounded-full bg-amber-300" />RRT*</span><span><i className="mr-1 inline-block size-1.5 rounded-full bg-violet-300" />DIJKSTRA</span></div>
  </div>
}

export function useSimulatorState() {
  return useState(true)
}
